package es.gestionpersonas.cuenta.api;

import es.gestionpersonas.cuenta.dto.CuentaDtos;
import es.gestionpersonas.cuenta.servicio.ServicioCuenta;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.validation.Valid;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/cuentas")
@Tag(name = "Cuentas", description = "Cuentas de usuario y contextos de acceso")
public class CuentaController {
    private final ServicioCuenta servicio;
    public CuentaController(ServicioCuenta servicio) { this.servicio = servicio; }

    @PostMapping @ResponseStatus(HttpStatus.CREATED)
    public CuentaDtos.Cuenta crear(@Valid @RequestBody CuentaDtos.CrearCuenta entrada) { return servicio.create(entrada); }

    @GetMapping("/{id}")
    public CuentaDtos.Cuenta obtener(@PathVariable Long id) { return servicio.get(id); }

    @PatchMapping("/{id}")
    public CuentaDtos.Cuenta modificar(@PathVariable Long id, @RequestBody CuentaDtos.ModificarCuenta entrada) { return servicio.update(id, entrada); }

    @DeleteMapping("/{id}") @ResponseStatus(HttpStatus.NO_CONTENT)
    public void deshabilitar(@PathVariable Long id) { servicio.disable(id); }

    @GetMapping("/{cuentaId}/contextos")
    public List<CuentaDtos.Contexto> contextos(@PathVariable Long cuentaId) { return servicio.contexts(cuentaId); }

    @PostMapping("/{cuentaId}/contextos") @ResponseStatus(HttpStatus.CREATED)
    public CuentaDtos.Contexto anadirContexto(@PathVariable Long cuentaId,
                                               @Valid @RequestBody CuentaDtos.CrearContexto entrada) {
        return servicio.addContext(cuentaId, entrada);
    }

    @PatchMapping("/{cuentaId}/contextos/{contextoId}")
    public CuentaDtos.Contexto modificarContexto(@PathVariable Long cuentaId, @PathVariable Long contextoId,
                                                  @RequestBody CuentaDtos.ModificarContexto entrada) {
        return servicio.updateContext(cuentaId, contextoId, entrada);
    }

    @DeleteMapping("/{cuentaId}/contextos/{contextoId}") @ResponseStatus(HttpStatus.NO_CONTENT)
    public void deshabilitarContexto(@PathVariable Long cuentaId, @PathVariable Long contextoId) {
        servicio.disableContext(cuentaId, contextoId);
    }
}
