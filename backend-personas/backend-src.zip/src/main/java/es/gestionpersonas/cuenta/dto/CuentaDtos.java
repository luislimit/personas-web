package es.gestionpersonas.cuenta.dto;

import jakarta.validation.constraints.*;
import java.time.LocalDateTime;

public final class CuentaDtos {
    private CuentaDtos() {}

    public record Cuenta(
        Long id,
        Long personaEntidadId,
        String nombreUsuario,
        String correoAcceso,
        String proveedorAutenticacion,
        boolean preferido,
        String estado,
        LocalDateTime ultimoAcceso
    ) {}

    public record Contexto(
        Long id,
        Long cuentaId,
        Long entidadContextoId,
        String nombreContexto,
        Long rolSeguridadId,
        String codigoRol,
        String nombreRol,
        String alcance,
        boolean habilitado,
        LocalDateTime validoDesde,
        LocalDateTime validoHasta
    ) {}

    public record CrearCuenta(
        @NotNull Long personaEntidadId,
        @NotBlank @Size(max=150) String nombreUsuario,
        String correoAcceso,
        @NotBlank String hashContrasena,
        String proveedorAutenticacion,
        String sujetoExterno,
        Boolean preferido,
        String estado
    ) {}

    public record ModificarCuenta(
        String correoAcceso,
        String hashContrasena,
        String proveedorAutenticacion,
        String sujetoExterno,
        Boolean preferido,
        String estado
    ) {}

    public record CrearContexto(
        @NotNull Long entidadContextoId,
        @NotBlank String codigoRol,
        String alcance,
        Boolean habilitado,
        LocalDateTime validoDesde,
        LocalDateTime validoHasta
    ) {}

    public record ModificarContexto(
        String alcance,
        Boolean habilitado,
        LocalDateTime validoDesde,
        LocalDateTime validoHasta
    ) {}
}
