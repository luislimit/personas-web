package es.gestionpersonas.solicitud.modelo;

import jakarta.persistence.*;
import java.time.LocalDateTime;

@Entity
@Table(name = "mensaje_solicitud")
public class MensajeSolicitud {
    @Id @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
    @Column(name = "solicitud_id", nullable = false)
    private Long requestId;
    @Column(name = "entidad_remitente_id", nullable = false)
    private Long senderEntityId;
    @Column(name = "mensaje", nullable = false, columnDefinition = "TEXT")
    private String message;
    @Column(name = "fecha_creacion", nullable = false)
    private LocalDateTime createdAt;

    protected MensajeSolicitud() {}
    public MensajeSolicitud(Long requestId, Long senderEntityId, String message) {
        this.requestId = requestId;
        this.senderEntityId = senderEntityId;
        this.message = message;
        this.createdAt = LocalDateTime.now();
    }

    public Long getId() { return id; }
    public Long getRequestId() { return requestId; }
    public Long getSenderEntityId() { return senderEntityId; }
    public String getMessage() { return message; }
    public LocalDateTime getCreatedAt() { return createdAt; }
}
