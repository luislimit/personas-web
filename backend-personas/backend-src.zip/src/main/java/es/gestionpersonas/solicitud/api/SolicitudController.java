package es.gestionpersonas.solicitud.api;

import es.gestionpersonas.solicitud.dto.SolicitudDtos;
import es.gestionpersonas.solicitud.servicio.ServicioSolicitud;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.validation.Valid;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/solicitudes")
@Tag(name = "Solicitudes", description = "Flujo genérico de solicitudes")
public class SolicitudController {
    private final ServicioSolicitud servicio;
    public SolicitudController(ServicioSolicitud servicio) { this.servicio = servicio; }

    @GetMapping public List<SolicitudDtos.Resumen> listar() { return servicio.list(); }
    @GetMapping("/{id}") public SolicitudDtos.Detalle obtener(@PathVariable Long id) { return servicio.get(id); }
    @PostMapping @ResponseStatus(HttpStatus.CREATED)
    public SolicitudDtos.Detalle crear(@Valid @RequestBody SolicitudDtos.CrearSolicitud entrada) { return servicio.create(entrada); }
    @PatchMapping("/{id}")
    public SolicitudDtos.Detalle modificar(@PathVariable Long id, @RequestBody SolicitudDtos.ModificarSolicitud entrada) { return servicio.update(id, entrada); }

    @PostMapping("/{id}/mensajes") @ResponseStatus(HttpStatus.CREATED)
    public SolicitudDtos.VistaMensaje anadirMensaje(@PathVariable Long id,
                                                     @Valid @RequestBody SolicitudDtos.AgregarMensaje entrada) {
        return servicio.addMessage(id, entrada);
    }

    @PostMapping("/{id}/participantes") @ResponseStatus(HttpStatus.CREATED)
    public SolicitudDtos.VistaParticipante anadirParticipante(@PathVariable Long id,
                                                               @Valid @RequestBody SolicitudDtos.EntradaParticipante entrada) {
        return servicio.addParticipant(id, entrada);
    }

    @PatchMapping("/{id}/participantes/{entidadId}")
    public SolicitudDtos.VistaParticipante modificarParticipante(
        @PathVariable Long id, @PathVariable Long entidadId,
        @RequestParam String rolParticipante,
        @Valid @RequestBody SolicitudDtos.ModificarParticipante entrada) {
        return servicio.updateParticipant(id, entidadId, rolParticipante, entrada);
    }

    @DeleteMapping("/{id}/participantes/{entidadId}") @ResponseStatus(HttpStatus.NO_CONTENT)
    public void eliminarParticipante(@PathVariable Long id, @PathVariable Long entidadId,
                                     @RequestParam String rolParticipante) {
        servicio.removeParticipant(id, entidadId, rolParticipante);
    }

    @PostMapping("/{id}/acciones") @ResponseStatus(HttpStatus.CREATED)
    public SolicitudDtos.VistaAccion accion(@PathVariable Long id,
                                             @Valid @RequestBody SolicitudDtos.EntradaAccion entrada) {
        return servicio.action(id, entrada);
    }
}
