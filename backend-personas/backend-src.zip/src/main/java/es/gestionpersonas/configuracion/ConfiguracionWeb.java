package es.gestionpersonas.configuracion;

import es.gestionpersonas.seguridad.web.InterceptorSeguridadApi;
import org.springframework.context.annotation.Configuration;
import org.springframework.web.servlet.config.annotation.*;

@Configuration
public class ConfiguracionWeb implements WebMvcConfigurer {
    private final InterceptorSeguridadApi securityInterceptor;

    public ConfiguracionWeb(InterceptorSeguridadApi securityInterceptor) {
        this.securityInterceptor = securityInterceptor;
    }

    @Override
    public void addInterceptors(InterceptorRegistry registry) {
        registry.addInterceptor(securityInterceptor)
            .addPathPatterns("/api/**");
    }

    @Override
    public void addCorsMappings(CorsRegistry registry) {
        registry.addMapping("/api/**")
            .allowedOrigins("http://localhost:3000", "http://localhost:5173")
            .allowedMethods("GET", "POST", "PUT", "PATCH", "DELETE", "OPTIONS")
            .allowedHeaders("*")
            .exposedHeaders("X-Contexto-Id");
    }
}
