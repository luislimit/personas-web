package es.gestionpersonas.seguridad.modelo;

import jakarta.persistence.*;
import java.time.LocalDateTime;

@Entity
@Table(name = "sesion_autenticacion")
public class SesionAutenticacion {
    @Id @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(name = "cuenta_id", nullable = false)
    private Long accountId;

    @Column(name = "hash_token", nullable = false, unique = true, length = 64)
    private String tokenHash;

    @Column(name = "fecha_creacion", nullable = false)
    private LocalDateTime createdAt;

    @Column(name = "fecha_expiracion", nullable = false)
    private LocalDateTime expiresAt;

    @Column(name = "ultimo_uso")
    private LocalDateTime lastSeenAt;

    @Column(name = "fecha_revocacion")
    private LocalDateTime revokedAt;

    protected SesionAutenticacion() {}

    public SesionAutenticacion(Long accountId, String tokenHash, LocalDateTime expiresAt) {
        this.accountId = accountId;
        this.tokenHash = tokenHash;
        this.createdAt = LocalDateTime.now();
        this.lastSeenAt = this.createdAt;
        this.expiresAt = expiresAt;
    }

    public void touch() { this.lastSeenAt = LocalDateTime.now(); }
    public void revoke() { if (this.revokedAt == null) this.revokedAt = LocalDateTime.now(); }

    public Long getId() { return id; }
    public Long getAccountId() { return accountId; }
    public String getTokenHash() { return tokenHash; }
    public LocalDateTime getCreatedAt() { return createdAt; }
    public LocalDateTime getExpiresAt() { return expiresAt; }
    public LocalDateTime getLastSeenAt() { return lastSeenAt; }
    public LocalDateTime getRevokedAt() { return revokedAt; }

    public boolean isActiveAt(LocalDateTime now) {
        return revokedAt == null && expiresAt.isAfter(now);
    }
}
