package es.gestionpersonas.seguridad.web;

import es.gestionpersonas.comun.ExcepcionNoAutorizado;

public final class ContextoAccesoActual {
    private static final ThreadLocal<AccesoActual> HOLDER = new ThreadLocal<>();
    private ContextoAccesoActual() {}

    public static void set(AccesoActual access) { HOLDER.set(access); }
    public static AccesoActual get() { return HOLDER.get(); }
    public static AccesoActual require() {
        AccesoActual value = HOLDER.get();
        if (value == null) throw new ExcepcionNoAutorizado("No existe contexto de acceso autenticado");
        return value;
    }
    public static void clear() { HOLDER.remove(); }
}
