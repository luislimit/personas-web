package es.gestionpersonas.seguridad.servicio;

import es.gestionpersonas.comun.*;
import es.gestionpersonas.seguridad.dto.AutenticacionDtos;
import es.gestionpersonas.seguridad.web.AccesoActual;
import jakarta.persistence.EntityManager;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.LocalDateTime;
import java.util.*;

@Service
@Transactional(readOnly = true)
public class ServicioControlAcceso {
    private final EntityManager em;
    private final ServicioAutenticacion authService;

    public ServicioControlAcceso(EntityManager em, ServicioAutenticacion authService) {
        this.em = em;
        this.authService = authService;
    }

    public AccesoActual resolve(Long sessionId, Long accountId, Long contextEntityId) {
        Object[] row = contextRow(accountId, contextEntityId);
        Long accountContextId = number(row[0]);
        Long personEntityId = row[1] == null ? null : number(row[1]);
        String roleCode = String.valueOf(row[2]);
        String alcance = row[3] == null ? null : String.valueOf(row[3]);

        Set<String> permissions = effectivePermissions(accountContextId, number(row[4]));
        return new AccesoActual(
            sessionId, accountId, personEntityId, accountContextId,
            contextEntityId, roleCode, alcance, Collections.unmodifiableSet(permissions)
        );
    }

    public AutenticacionDtos.RespuestaContextoActivo activate(Long accountId, Long contextEntityId) {
        AccesoActual access = resolve(null, accountId, contextEntityId);
        AutenticacionDtos.VistaContexto context = authService.contexts(accountId).stream()
            .filter(c -> Objects.equals(c.entidadContextoId(), contextEntityId))
            .findFirst()
            .orElseThrow(() -> new ExcepcionProhibido("El contexto no está disponible para la cuenta"));
        return new AutenticacionDtos.RespuestaContextoActivo(context, access.permissions());
    }

    public void requirePermission(AccesoActual access, String permiso) {
        if (!access.permissions().contains(permiso)) {
            throw new ExcepcionProhibido("Permiso requerido: " + permiso);
        }
    }

    public boolean hasPermission(AccesoActual access, String permiso) {
        return access.permissions().contains(permiso);
    }

    public boolean canReadPersonalData(AccesoActual access, Long targetEntityId) {
        return canPersonalData(access, targetEntityId, false);
    }

    public boolean canUpdatePersonalData(AccesoActual access, Long targetEntityId) {
        return canPersonalData(access, targetEntityId, true);
    }

    public void requireReadPersonalData(AccesoActual access, Long targetEntityId) {
        if (!canReadPersonalData(access, targetEntityId))
            throw new ExcepcionProhibido("No tiene permiso para consultar los datos personales de la entidad " + targetEntityId);
    }

    public void requireUpdatePersonalData(AccesoActual access, Long targetEntityId) {
        if (!canUpdatePersonalData(access, targetEntityId))
            throw new ExcepcionProhibido("No tiene permiso para modificar los datos personales de la entidad " + targetEntityId);
    }

    private boolean canPersonalData(AccesoActual access, Long targetEntityId, boolean update) {
        if (access.personEntityId() != null && Objects.equals(access.personEntityId(), targetEntityId)) {
            return true;
        }

        if ("RELACIONADOS".equalsIgnoreCase(access.alcance())
            && access.personEntityId() != null
            && isChildOrWard(access.personEntityId(), targetEntityId)) {
            return true;
        }

        return access.permissions().contains(update ? "DATOS_PERSONALES.MODIFICAR" : "DATOS_PERSONALES.LEER");
    }

    private boolean isChildOrWard(Long personId, Long targetId) {
        Number count = (Number) em.createNativeQuery("""
            select count(*)
              from relacion_entidad er
              join tipo_relacion rt on rt.id = er.tipo_relacion_id
             where er.entidad_origen_id = :personId
               and er.entidad_destino_id = :targetId
               and er.estado = 'ACTIVO'
               and (er.valido_desde is null or er.valido_desde <= current_date())
               and (er.valido_hasta is null or er.valido_hasta >= current_date())
               and rt.codigo in ('PADRE_HIJO','TUTOR_TUTELADO')
            """)
            .setParameter("personId", personId)
            .setParameter("targetId", targetId)
            .getSingleResult();
        return count.longValue() > 0;
    }

    @SuppressWarnings("unchecked")
    private Set<String> effectivePermissions(Long accountContextId, Long roleId) {
        Set<String> permissions = new LinkedHashSet<>();
        List<?> rolePermRows = em.createNativeQuery("""
            select p.codigo
              from rol_seguridad_permiso rp
              join permiso p on p.id = rp.permiso_id
             where rp.rol_seguridad_id = :roleId
            """)
            .setParameter("roleId", roleId)
            .getResultList();
        rolePermRows.stream().map(String::valueOf).forEach(permissions::add);

        List<Object[]> overrides = em.createNativeQuery("""
            select p.codigo, apo.efecto
              from excepcion_permiso_acceso apo
              join permiso p on p.id = apo.permiso_id
             where apo.contexto_cuenta_id = :accountContextId
            """)
            .setParameter("accountContextId", accountContextId)
            .getResultList();

        for (Object[] row : overrides) {
            String code = String.valueOf(row[0]);
            String efecto = String.valueOf(row[1]);
            if ("DENEGAR".equals(efecto)) permissions.remove(code);
            else if ("PERMITIR".equals(efecto)) permissions.add(code);
        }
        return permissions;
    }

    private Object[] contextRow(Long accountId, Long contextEntityId) {
        List<?> rows = em.createNativeQuery("""
            select ac.id, ua.persona_entidad_id, r.codigo, ac.alcance, r.id
              from contexto_cuenta ac
              join cuenta_usuario ua on ua.id = ac.cuenta_id
              join rol_seguridad r on r.id = ac.rol_seguridad_id
             where ac.cuenta_id = :accountId
               and ac.entidad_contexto_id = :contextId
               and ac.habilitado = true
               and ua.estado = 'ACTIVO'
               and (ac.valido_desde is null or ac.valido_desde <= now(6))
               and (ac.valido_hasta is null or ac.valido_hasta >= now(6))
             order by case when r.codigo='ADMIN_PLATAFORMA' then 0 else 1 end, ac.id
             limit 1
            """)
            .setParameter("accountId", accountId)
            .setParameter("contextId", contextEntityId)
            .getResultList();
        if (rows.isEmpty()) throw new ExcepcionProhibido("El contexto no está habilitado para esta cuenta");
        return (Object[]) rows.get(0);
    }

    private Long number(Object value) { return ((Number) value).longValue(); }
}
