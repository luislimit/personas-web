package es.gestionpersonas.seguridad.api;

import es.gestionpersonas.comun.ExcepcionNoAutorizado;
import es.gestionpersonas.seguridad.dto.AutenticacionDtos;
import es.gestionpersonas.seguridad.modelo.SesionAutenticacion;
import es.gestionpersonas.seguridad.servicio.ServicioAutenticacion;
import es.gestionpersonas.seguridad.servicio.ServicioControlAcceso;
import es.gestionpersonas.seguridad.web.ContextoAccesoActual;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.validation.Valid;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/autenticacion")
@Tag(name = "Autenticación", description = "Autenticación, sesión y selección de contexto")
public class AutenticacionController {
    private final ServicioAutenticacion servicioAutenticacion;
    private final ServicioControlAcceso controlAcceso;

    public AutenticacionController(ServicioAutenticacion servicioAutenticacion, ServicioControlAcceso controlAcceso) {
        this.servicioAutenticacion = servicioAutenticacion;
        this.controlAcceso = controlAcceso;
    }

    @PostMapping("/iniciar-sesion")
    public AutenticacionDtos.RespuestaInicioSesion iniciarSesion(
        @Valid @RequestBody AutenticacionDtos.SolicitudInicioSesion entrada) {
        return servicioAutenticacion.login(entrada);
    }

    @PostMapping("/cerrar-sesion") @ResponseStatus(HttpStatus.NO_CONTENT)
    public void cerrarSesion(HttpServletRequest solicitud) {
        servicioAutenticacion.logout(bearer(solicitud.getHeader("Authorization")));
    }

    @GetMapping("/yo")
    public AutenticacionDtos.RespuestaYo yo() {
        return servicioAutenticacion.me(ContextoAccesoActual.require().accountId());
    }

    @GetMapping("/contextos")
    public java.util.List<AutenticacionDtos.VistaContexto> contextos() {
        return servicioAutenticacion.contexts(ContextoAccesoActual.require().accountId());
    }

    @PostMapping("/contextos/{entidadContextoId}/activar")
    public AutenticacionDtos.RespuestaContextoActivo activar(
        @PathVariable Long entidadContextoId, HttpServletRequest solicitud) {
        SesionAutenticacion sesion = servicioAutenticacion.authenticate(bearer(solicitud.getHeader("Authorization")));
        return controlAcceso.activate(sesion.getAccountId(), entidadContextoId);
    }

    private String bearer(String cabecera) {
        if (cabecera == null || !cabecera.regionMatches(true, 0, "Bearer ", 0, 7)) {
            throw new ExcepcionNoAutorizado("Cabecera Authorization Bearer obligatoria");
        }
        return cabecera.substring(7).trim();
    }
}
