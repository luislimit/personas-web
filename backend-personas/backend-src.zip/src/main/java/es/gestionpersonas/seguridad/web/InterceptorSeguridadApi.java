package es.gestionpersonas.seguridad.web;

import es.gestionpersonas.comun.ExcepcionNoAutorizado;
import es.gestionpersonas.comun.ExcepcionProhibido;
import es.gestionpersonas.seguridad.modelo.SesionAutenticacion;
import es.gestionpersonas.seguridad.servicio.ServicioAutenticacion;
import es.gestionpersonas.seguridad.servicio.ServicioControlAcceso;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import org.springframework.stereotype.Component;
import org.springframework.web.servlet.HandlerInterceptor;

import java.util.Set;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

@Component
public class InterceptorSeguridadApi implements HandlerInterceptor {
    private static final Pattern ENTIDAD_ID = Pattern.compile("^/api/entidades/(\\d+)(?:/.*)?$");
    private final ServicioAutenticacion servicioAutenticacion;
    private final ServicioControlAcceso controlAcceso;

    public InterceptorSeguridadApi(ServicioAutenticacion servicioAutenticacion, ServicioControlAcceso controlAcceso) {
        this.servicioAutenticacion = servicioAutenticacion;
        this.controlAcceso = controlAcceso;
    }

    @Override
    public boolean preHandle(HttpServletRequest solicitud, HttpServletResponse respuesta, Object manejador) {
        ContextoAccesoActual.clear();
        String ruta = solicitud.getRequestURI();
        if (!ruta.startsWith("/api/")) return true;
        if ("OPTIONS".equalsIgnoreCase(solicitud.getMethod())) return true;
        if (ruta.equals("/api/sistema/salud") || ruta.equals("/api/autenticacion/iniciar-sesion")) return true;

        String token = bearer(solicitud.getHeader("Authorization"));
        SesionAutenticacion sesion = servicioAutenticacion.authenticate(token);
        Long cuentaId = sesion.getAccountId();

        if (ruta.equals("/api/autenticacion/yo") || ruta.equals("/api/autenticacion/cerrar-sesion")
            || ruta.equals("/api/autenticacion/contextos")) {
            ContextoAccesoActual.set(new AccesoActual(sesion.getId(), cuentaId, null, null, null, null, null, Set.of()));
            return true;
        }

        if (ruta.matches("^/api/autenticacion/contextos/\\d+/activar$")) return true;

        String cabeceraContexto = solicitud.getHeader("X-Contexto-Id");
        if (cabeceraContexto == null || cabeceraContexto.isBlank()) {
            throw new ExcepcionNoAutorizado("Cabecera X-Contexto-Id obligatoria");
        }

        Long entidadContextoId;
        try { entidadContextoId = Long.valueOf(cabeceraContexto); }
        catch (NumberFormatException ex) { throw new ExcepcionNoAutorizado("X-Contexto-Id no válido"); }

        AccesoActual acceso = controlAcceso.resolve(sesion.getId(), cuentaId, entidadContextoId);
        ContextoAccesoActual.set(acceso);
        autorizar(solicitud, acceso);
        return true;
    }

    @Override
    public void afterCompletion(HttpServletRequest solicitud, HttpServletResponse respuesta,
                                Object manejador, Exception ex) {
        ContextoAccesoActual.clear();
    }

    private void autorizar(HttpServletRequest solicitud, AccesoActual acceso) {
        String ruta = solicitud.getRequestURI();
        String metodo = solicitud.getMethod();

        if (ruta.startsWith("/api/entidades")) {
            Matcher coincidencia = ENTIDAD_ID.matcher(ruta);
            Long entidadDestinoId = coincidencia.matches() ? Long.valueOf(coincidencia.group(1)) : null;

            if (ruta.contains("/contactos")) {
                if (entidadDestinoId == null) throw new ExcepcionProhibido("Entidad objetivo no determinada");
                if ("GET".equals(metodo)) controlAcceso.requireReadPersonalData(acceso, entidadDestinoId);
                else controlAcceso.requireUpdatePersonalData(acceso, entidadDestinoId);
                return;
            }
            if (ruta.contains("/cuentas")) {
                controlAcceso.requirePermission(acceso, "CUENTA.LEER");
                return;
            }
            if (ruta.contains("/documentos")) {
                controlAcceso.requirePermission(acceso, "DOCUMENTO.LEER");
                return;
            }
            if (ruta.contains("/relaciones")) {
                controlAcceso.requirePermission(acceso, "GET".equals(metodo) ? "ENTIDAD.LEER" : "ENTIDAD.MODIFICAR");
                return;
            }
            controlAcceso.requirePermission(acceso, permiso("ENTIDAD", metodo));
            return;
        }

        if (ruta.startsWith("/api/cuentas")) {
            controlAcceso.requirePermission(acceso,
                ruta.contains("/contextos") ? permiso("CONTEXTO", metodo) : permiso("CUENTA", metodo));
            return;
        }
        if (ruta.startsWith("/api/calendarios")) {
            controlAcceso.requirePermission(acceso,
                ruta.contains("/eventos") ? permiso("EVENTO", metodo) : permiso("CALENDARIO", metodo));
            return;
        }
        if (ruta.startsWith("/api/eventos")) {
            controlAcceso.requirePermission(acceso, permiso("EVENTO", metodo));
            return;
        }
        if (ruta.startsWith("/api/documentos")) {
            if (ruta.matches("^/api/documentos/\\d+/acceder$") && "POST".equals(metodo)) {
                controlAcceso.requirePermission(acceso, "DOCUMENTO.LEER");
            } else {
                controlAcceso.requirePermission(acceso, permiso("DOCUMENTO", metodo));
            }
            return;
        }
        if (ruta.startsWith("/api/solicitudes")) {
            String codigoPermiso;
            if (ruta.contains("/acciones") || ruta.contains("/participantes") || ruta.contains("/mensajes")) {
                codigoPermiso = "SOLICITUD.MODIFICAR";
            } else if ("DELETE".equals(metodo)) {
                codigoPermiso = "SOLICITUD.CANCELAR";
            } else {
                codigoPermiso = permiso("SOLICITUD", metodo);
            }
            controlAcceso.requirePermission(acceso, codigoPermiso);
            return;
        }

        throw new ExcepcionProhibido("Endpoint sin política de autorización configurada");
    }

    private String permiso(String familia, String metodo) {
        return switch (metodo) {
            case "GET", "HEAD" -> familia + ".LEER";
            case "POST" -> familia + ".CREAR";
            case "PUT", "PATCH" -> familia + ".MODIFICAR";
            case "DELETE" -> familia + ".ELIMINAR";
            default -> throw new ExcepcionProhibido("Método HTTP no autorizado");
        };
    }

    private String bearer(String cabecera) {
        if (cabecera == null || !cabecera.regionMatches(true, 0, "Bearer ", 0, 7)) {
            throw new ExcepcionNoAutorizado("Cabecera Authorization Bearer obligatoria");
        }
        return cabecera.substring(7).trim();
    }
}
