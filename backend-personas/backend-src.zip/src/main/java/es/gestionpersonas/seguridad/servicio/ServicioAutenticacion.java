package es.gestionpersonas.seguridad.servicio;

import es.gestionpersonas.cuenta.modelo.CuentaUsuario;
import es.gestionpersonas.cuenta.repositorio.RepositorioCuentaUsuario;
import es.gestionpersonas.comun.*;
import es.gestionpersonas.seguridad.dto.AutenticacionDtos;
import es.gestionpersonas.seguridad.modelo.SesionAutenticacion;
import es.gestionpersonas.seguridad.repositorio.RepositorioSesionAutenticacion;
import jakarta.persistence.EntityManager;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.security.crypto.factory.PasswordEncoderFactories;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.security.SecureRandom;
import java.time.LocalDateTime;
import java.util.*;
import java.util.Base64;

@Service
@Transactional(readOnly = true)
public class ServicioAutenticacion {
    private final RepositorioCuentaUsuario accounts;
    private final RepositorioSesionAutenticacion sessions;
    private final EntityManager em;
    private final PasswordEncoder passwordEncoder = PasswordEncoderFactories.createDelegatingPasswordEncoder();
    private final SecureRandom secureRandom = new SecureRandom();
    private final long sessionHours;

    public ServicioAutenticacion(RepositorioCuentaUsuario accounts,
                       RepositorioSesionAutenticacion sessions,
                       EntityManager em,
                       @Value("${app.security.session-hours:12}") long sessionHours) {
        this.accounts = accounts;
        this.sessions = sessions;
        this.em = em;
        this.sessionHours = sessionHours;
    }

    @Transactional
    public AutenticacionDtos.RespuestaInicioSesion login(AutenticacionDtos.SolicitudInicioSesion input) {
        CuentaUsuario account = accounts.findByUsername(input.nombreUsuario().trim())
            .orElseThrow(() -> new ExcepcionNoAutorizado("Usuario o contraseña incorrectos"));

        if (!"ACTIVO".equals(account.getStatus())) {
            throw new ExcepcionNoAutorizado("La cuenta no está activa");
        }
        if (!"LOCAL".equalsIgnoreCase(account.getAuthProvider())) {
            throw new ExcepcionNoAutorizado("Esta cuenta utiliza un proveedor de autenticación externo");
        }
        if (!passwordEncoder.matches(input.contrasena(), account.getPasswordHash())) {
            throw new ExcepcionNoAutorizado("Usuario o contraseña incorrectos");
        }

        byte[] raw = new byte[32];
        secureRandom.nextBytes(raw);
        String token = Base64.getUrlEncoder().withoutPadding().encodeToString(raw);
        String hash = sha256(token);
        LocalDateTime expiresAt = LocalDateTime.now().plusHours(sessionHours);

        SesionAutenticacion session = sessions.save(new SesionAutenticacion(account.getId(), hash, expiresAt));
        account.markLogin();

        return new AutenticacionDtos.RespuestaInicioSesion(
            token, "Bearer", expiresAt, account.getId(), account.getPersonEntityId(),
            account.getUsername(), contexts(account.getId())
        );
    }

    @Transactional
    public void logout(String rawToken) {
        SesionAutenticacion session = authenticate(rawToken);
        session.revoke();
    }

    @Transactional
    public SesionAutenticacion authenticate(String rawToken) {
        if (rawToken == null || rawToken.isBlank()) throw new ExcepcionNoAutorizado("Token Bearer obligatorio");
        SesionAutenticacion session = sessions.findByTokenHash(sha256(rawToken))
            .orElseThrow(() -> new ExcepcionNoAutorizado("Sesión no válida"));

        if (!session.isActiveAt(LocalDateTime.now())) {
            throw new ExcepcionNoAutorizado("La sesión ha caducado o ha sido revocada");
        }

        CuentaUsuario account = accounts.findById(session.getAccountId())
            .orElseThrow(() -> new ExcepcionNoAutorizado("La cuenta de la sesión ya no existe"));
        if (!"ACTIVO".equals(account.getStatus())) {
            throw new ExcepcionNoAutorizado("La cuenta no está activa");
        }

        session.touch();
        return session;
    }

    public AutenticacionDtos.RespuestaYo me(Long accountId) {
        CuentaUsuario account = accounts.findById(accountId)
            .orElseThrow(() -> new ExcepcionNoAutorizado("Cuenta no válida"));
        return new AutenticacionDtos.RespuestaYo(
            account.getId(), account.getPersonEntityId(), account.getUsername(),
            account.getLoginEmail(), contexts(accountId)
        );
    }

    @SuppressWarnings("unchecked")
    public List<AutenticacionDtos.VistaContexto> contexts(Long accountId) {
        List<Object[]> rows = em.createNativeQuery("""
            select ac.id, ac.entidad_contexto_id, e.nombre, et.codigo,
                   r.id, r.codigo, r.nombre, ac.alcance, ac.valido_desde, ac.valido_hasta
              from contexto_cuenta ac
              join entidad e on e.id = ac.entidad_contexto_id
              join tipo_entidad et on et.id = e.tipo_entidad_id
              join rol_seguridad r on r.id = ac.rol_seguridad_id
             where ac.cuenta_id = :accountId
               and ac.habilitado = true
               and (ac.valido_desde is null or ac.valido_desde <= now(6))
               and (ac.valido_hasta is null or ac.valido_hasta >= now(6))
             order by e.nombre, r.nombre
            """)
            .setParameter("accountId", accountId)
            .getResultList();

        return rows.stream().map(r -> new AutenticacionDtos.VistaContexto(
            number(r[0]), number(r[1]), String.valueOf(r[2]), String.valueOf(r[3]),
            number(r[4]), String.valueOf(r[5]), String.valueOf(r[6]),
            r[7] == null ? null : String.valueOf(r[7]),
            toLocalDateTime(r[8]), toLocalDateTime(r[9])
        )).toList();
    }

    public String sha256(String value) {
        try {
            MessageDigest md = MessageDigest.getInstance("SHA-256");
            byte[] digest = md.digest(value.getBytes(StandardCharsets.UTF_8));
            return HexFormat.of().formatHex(digest);
        } catch (Exception e) {
            throw new IllegalStateException("No se pudo calcular el hash de sesión", e);
        }
    }

    private Long number(Object value) { return ((Number) value).longValue(); }
    private LocalDateTime toLocalDateTime(Object value) {
        if (value == null) return null;
        if (value instanceof LocalDateTime ldt) return ldt;
        if (value instanceof java.sql.Timestamp ts) return ts.toLocalDateTime();
        throw new IllegalStateException("Fecha inesperada: " + value.getClass());
    }
}
